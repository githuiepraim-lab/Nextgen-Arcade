# NextGen Arcade Management System

## Quick Deploy (Railway — Free)
1. Push this folder to GitHub
2. Go to railway.app → New Project → Deploy from GitHub repo
3. Set environment variables in Railway dashboard:
   - AT_USERNAME   = your_africastalking_username
   - AT_APIKEY     = your_africastalking_api_key
   - STAFF_PHONE   = +254XXXXXXXXX  (staff phone for alerts)
   - ADMIN_PHONE   = +254XXXXXXXXX  (your phone for integrity checks)
4. Deploy! Railway gives you a free .railway.app domain instantly.

## Features
### Per-Game Pricing
- Each game has a base hourly rate + optional surcharge
- Elden Ring: +KES 150/session | Spider-Man 2: +KES 100 | etc.
- Set surcharges in Admin → Games tab
- Customers see full breakdown before paying

### AI Integrity Checks
- When a session starts, AI schedules 4 RANDOM spot-checks
- Checks are spread across session quarters (unpredictable timing)
- Each check fires an SMS to admin: "Verify PS5 #X on CCTV"
- Admin marks each check as Verified or Flagged in admin panel
- View all checks in Admin → Integrity tab

### SMS Events (Africa's Talking)
- Customer books → confirmation SMS with full price breakdown
- Session timer ends → SMS to customer + staff
- Session ended by staff → receipt SMS to customer
- M-Pesa STK push → payment prompt SMS
- Integrity check → random CCTV alert to admin

## API Endpoints
POST /api/book                   Book a station (schedules integrity checks)
POST /api/end/:id                End session (sends receipt SMS)
POST /api/pricing/estimate       Get charge breakdown for game+duration
GET  /api/integrity/log          All integrity checks log
GET  /api/integrity/schedule/:id Upcoming checks for a station
POST /api/integrity/verify       Mark a check as verified/flagged
GET  /api/stats                  Full revenue & analytics
